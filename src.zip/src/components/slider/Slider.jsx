import React,{ useRef } from 'react'
import './Slider.css'
import HeadingTitle from '../heading-title/HeadingTitle'
import Rating from '../rating/Rating';

function Carrousel({data}) {

    const carrouselRef = useRef()
    const box = carrouselRef.current

    const handlePrevClick = () => {
        let width = box.clientWidth
        box.scrollLeft = box.scrollLeft - width
        console.log(box.clientWidth);
    }

    const handleNextClick = () => {
        let width = box.clientWidth
        box.scrollLeft = box.scrollLeft + width
        console.log(box.clientWidth);
    }

  return (
    <div className='slider-container'>
        <HeadingTitle 
            title = "New Laptops"
            arrowContainer = {true}
            handlePrevClick = { handlePrevClick }
            handleNextClick = { handleNextClick }
            data = { data }
        />

        <div className="slider-wrapper" ref={carrouselRef}>
            {data.map((item) => (
            <div  className="slide" 
                key={item.id} 
                // style={{ transform: `translate(${slideIndex * -250}px)` }}
            >
                <img className="slide-image" src={item.image} alt={item.title} />
                <h3 className="slide-title">{item.title}</h3>

                <Rating 
                    rating={item.rating} 
                    reviews={item.reviews} 
                />

                <div className="slide-price">${item.price}</div>
            </div>
            ))}
        </div>

    </div>
  )
}

export default Carrousel