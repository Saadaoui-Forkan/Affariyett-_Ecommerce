import React,{useState} from 'react'
import './Header.css'
import HeaderTop from "./HeaderTop";
import Navbar from "./Navbar";

function Header() {

  const [nav, setNav] = useState('.navbar-links')

  const animateNav = () => {
    nav === '.navbar-links' ? setNav('.navbar-links .active-navbar') : setNav('.navbar-links')
  }

  return (
    <div>
      <HeaderTop />
      <Navbar 
        animateNav = { animateNav }
        nav = { nav }
      />
    </div>
  )
}

export default Header
