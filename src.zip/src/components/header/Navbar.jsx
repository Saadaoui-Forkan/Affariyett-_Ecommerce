import React,{useState} from 'react'

function Navbar({ animateNav,nav }) {
    
  return (
    <nav className="navbar">
        <div className="toggle-icons">
            <div className="burger-icon"  onClick = { animateNav }>
                <i className="bi bi-list"></i>
            </div>
            <div className="close-icon">
                <i className="bi bi-x-lg"></i> 
            </div>
        </div>

        <ul className = {nav}>
            <li className="navbar-link">
                Home
            </li>
            <li className="navbar-link">
                Electronics and mobiles
            </li>
            <li className="navbar-link">
                Home and kitchen
            </li>
            <li className="navbar-link">
                Mens
            </li>
            <li className="navbar-link">
                Women
            </li>
        </ul>
    </nav>
  )
}

export default Navbar
