export const categories = [
    {
        id:1,
        title: "phones",
        image: "/images/products/category/m12.jpg",
    },
    {
        id:2,
        title: "laptops",
        image: "/images/products/category/l4.jpg",
    },
    {
        id:3,
        title: "Devices to wear",
        image: "/images/products/category/o19.jpg",
    },
    {
        id:4,
        title: "headphones",
        image: "/images/products/category/o20.jpg",
    },
    {
        id:5,
        title: "Furniture",
        image: "/images/products/category/chair.jpg",
    },
    {
        id:6,
        title: "sports shoes",
        image: "/images/products/category/jordan2.png",
    },
    {
        id:7,
        title: "watches",
        image: "/images/products/category/o24.jpg",
    },
    {
        id:8,
        title: "Stationery store",
        image: "/images/products/category/o4.jpg",
    },
    {
        id:9,
        title: "Women's fashion",
        image: "/images/products/category/pngaaa.png",
    },
    {
        id:10,
        title: "Women's fashion",
        image: "/images/products/category/pngaaam.png",
    },
    {
        id:11,
        title: "Sportswear",
        image: "/images/products/category/sport.png",
    },
    {
        id:12,
        title: "Cleanliness",
        image: "/images/products/category/o23.jpg",
    },
]